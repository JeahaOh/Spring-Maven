package com.company.login;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



@Repository
public class LoginDAO {
	
	@Autowired
	private SqlSessionTemplate tem;
	private static final Logger logger = LoggerFactory.getLogger(LoginDAO.class);
	
	public LoginDTO select(String id,String pw) {
		LoginDTO dto = new LoginDTO();
		dto.setUserId(id);
		dto.setUserPw(pw);
		dto=tem.selectOne("login.loginselect", dto);
		return dto;
	}	
	
	public int loginSerach(String id, String pw) {
		LoginDTO check=tem.selectOne("login.count", id);
		int count=0;
		try {
			if(check.getUserId().equals(id) &&!check.getUserPw().equals(pw)) {
				count=1;
			}else if(check.getUserId().equals(id)&&check.getUserPw().equals(pw)) {
				count=1;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return count;
	}	
	
}
