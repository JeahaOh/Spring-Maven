package com.company.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LogingController {

	@Autowired
	LoginDAO dao;
	
	@RequestMapping("login.do")
	public ModelAndView loginCheck(HttpServletResponse res,HttpServletRequest req) throws ServletException, IOException{
		ModelAndView mav = new ModelAndView();
		LoginDTO dto = new LoginDTO();
		String id=req.getParameter("userId");
		String pw=req.getParameter("userPw");
		
		try {
		
			dto=dao.select(id,pw);
			int count = dao.loginSerach(id,pw);
			if(count == 2) {
				mav.setViewName("TsBoard/tsBoardList");
			}else if(count==1){
				PrintWriter out = res.getWriter();
				
				out.print("<script>alert('�α��� ������ Ȯ���ϼ���.'); history.go(-1);</script>");
				mav.setViewName("id");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
	
	
}
