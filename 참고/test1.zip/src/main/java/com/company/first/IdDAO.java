package com.company.first;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

@Repository
public class IdDAO {

	@Autowired
	SqlSessionTemplate temp;

	public List<IdDTO> idSelect(){
		List<IdDTO> list = temp.selectList("id.idselect");				
		return list;
	}	
}
