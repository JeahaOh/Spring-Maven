package com.company.first;

public class IdDTO {
	String id;
	String password;
	int userNo;
	String gender;
	int tell_number;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getTell_number() {
		return tell_number;
	}
	public void setTell_number(int tell_number) {
		this.tell_number = tell_number;
	}
	
	
	
}
