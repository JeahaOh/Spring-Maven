package com.company.first;

/*
 * �ۼ���:���̻�
 * ��������� �׽�Ʈ��
 * �ۼ���:2018-07-03
 */

import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class IdController {
	
	@Autowired
	IdDAO dao;

	
	@RequestMapping(value = "/id.do", method = RequestMethod.GET)
	public ModelAndView id(Locale locale, Model model) {
			
			List<IdDTO> idSelect = dao.idSelect();
			ModelAndView mav = new ModelAndView();
			
		try {			
			mav.addObject("select",idSelect);
			mav.setViewName("id");			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return mav;
	}
	
}
