package com.company.board;

import java.util.Date;

public class TsBoardDTO {
		int qna_id;
		String userid;
		String title;
		String Contents;
		Date wdate;
		int Count;
		
		public int getQna_id() {
			return qna_id;
		}
		public void setQna_id(int qna_id) {
			this.qna_id = qna_id;
		}
		public String getUserid() {
			return userid;
		}
		public void setUserid(String userid) {
			this.userid = userid;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getContents() {
			return Contents;
		}
		public void setContents(String contents) {
			Contents = contents;
		}
		public Date getWdate() {
			return wdate;
		}
		public void setWdate(Date wdate) {
			this.wdate = wdate;
		}
		public int getCount() {
			return Count;
		}
		public void setCount(int count) {
			Count = count;
		}
		
		
		
		
}
