package com.company.board;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TsBoardController {
	
	
	@Autowired
	TsBoardDAO dao;
	
	@RequestMapping(value="/BoardList.do")
	private ModelAndView TsBoardList(TsBoardDTO dto) {
		ModelAndView mav = new ModelAndView("TsBoard/tsBoardList");
		
		try {
			List<TsBoardDTO> list = dao.BoardList();
			mav.addObject("list",list);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
}
