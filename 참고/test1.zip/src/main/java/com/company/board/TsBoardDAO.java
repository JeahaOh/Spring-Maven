package com.company.board;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class TsBoardDAO {
	
	@Autowired
	private SqlSessionTemplate temp; 
	
	public List<TsBoardDTO> BoardList(){
		List<TsBoardDTO> list = temp.selectList("Tsboard.tbselect");
		return list;
	}
}
