package com.example.dto;

public class MemberVO {

	private int num;
	private String id;
	private String pw;
	
	public MemberVO() {
		super();
		System.out.println("getNum() = " + getNum());
	}
	public MemberVO(int num, String id, String pw) {
		super();
		this.num = num;
		this.id = id;
		this.pw = pw;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	

	
}
