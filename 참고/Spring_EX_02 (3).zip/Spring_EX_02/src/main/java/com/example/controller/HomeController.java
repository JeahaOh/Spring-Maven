package com.example.controller;

import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.dao.MemberDAO;
import com.example.dto.MemberVO;
import com.example.service.MemberService;


@Controller
public class HomeController {

	@Inject
	private MemberService service;
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) throws Exception{
		System.out.println("1- 컨트롤러 시작");
		
		List<MemberVO> memberList = service.selectMember();
		System.out.println("4- 다녀옴");
		
		System.out.println(memberList);
//		System.out.println(memberList);

		model.addAttribute("memberList", memberList);
		System.out.println("5- model에 등록");

		return "home";
	}
	
}
