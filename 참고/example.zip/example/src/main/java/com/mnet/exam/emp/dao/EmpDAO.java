package com.mnet.exam.emp.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

public interface EmpDAO {

	List<Map> empList(SqlSessionTemplate session);
}
