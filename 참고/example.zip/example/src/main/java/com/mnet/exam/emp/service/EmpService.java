package com.mnet.exam.emp.service;

import java.util.List;
import java.util.Map;

public interface EmpService {
	
	List<Map> empList();
}
